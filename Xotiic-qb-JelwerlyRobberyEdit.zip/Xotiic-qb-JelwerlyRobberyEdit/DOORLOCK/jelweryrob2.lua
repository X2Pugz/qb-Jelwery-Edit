

-- -1558142560 created by Xotiic ツ
Config.DoorList['jelweryrob2--1558142560'] = {
    distance = 2,
    items = { ['thermite'] = 1 },
    objName = -1558142560,
    locked = true,
    objCoords = vec3(347.013885, -875.564758, 29.457197),
    doorRate = 1.0,
    objYaw = 0.0,
    fixText = false,
    doorType = 'door',
}