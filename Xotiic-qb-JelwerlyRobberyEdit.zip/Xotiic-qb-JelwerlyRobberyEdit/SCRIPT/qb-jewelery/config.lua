Config = Config or {}

-- Set to true or false or GetConvar('UseTarget', 'false') == 'true' to use global option or script specific
-- These have to be a string thanks to how Convars are returned.
Config.UseTarget = GetConvar('UseTarget', 'false') == 'true'

Config.Timeout = 30 * (60 * 2000)
Config.RequiredCops = 0
Config.JewelleryLocation = {
    ['coords'] = vector3(343.52, -879.02, 29.35),
}

Config.WhitelistedWeapons = {
[`weapon_crowbar`] = {
        ['timeOut'] = 10000
    },
}

Config.VitrineRewards = {
    [1] = {
        ['item'] = 'rolex',
        ['amount'] = {
            ['min'] = 1,
            ['max'] = 4
        },
        ['probability'] = 0.4
    },
    [2] = {
        ['item'] = 'diamond_ring',
        ['amount'] = {
            ['min'] = 1,
            ['max'] = 4
        },
        ['probability'] = 0.3
    },
    [3] = {
        ['item'] = 'goldchain',
        ['amount'] = {
            ['min'] = 1,
            ['max'] = 4
        },
        ['probability'] = 0.2
    },
    [4] = {
        ['item'] = 'tenkgoldchain',
        ['amount'] = {
            ['min'] = 1,
            ['max'] = 4
        },
        ['probability'] = 0.1
    },
}

Config.Locations = {
    [1] = {
        ['coords'] = vector3(344.02, -878.65, 29.47),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [2] = {
        ['coords'] = vector3(342.91, -878.42, 29.44),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [3] = {
        ['coords'] = vector3(342.35, -877.32, 29.49),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [4] = {
        ['coords'] = vector3(341.76, -880.84, 29.44),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [5] = {
        ['coords'] = vector3(341.68, -882.48, 29.47),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [6] = {
        ['coords'] = vector3(343.1, -882.59, 29.45),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [7] = {
        ['coords'] = vector3(345.16, -881.91, 29.37),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [8] = {
        ['coords'] = vector3(346.38, -881.35, 29.45),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [9] = {
        ['coords'] = vector3(346.38, -882.68, 29.43),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [10] = {
        ['coords'] = vector3(346.46, -884.29, 29.47),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [11] = {
        ['coords'] = vector3(346.38, -885.33, 29.36),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [12] = {
        ['coords'] = vector3(346.34, -887.61, 29.53),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [13] = {
        ['coords'] = vector3(341.61, -887.64, 29.47),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [14] = {
        ['coords'] = vector3(337.98, -887.53, 28.97),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [15] = {
        ['coords'] = vector3(340.37, -881.91, 29.48),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [16] = {
        ['coords'] = vector3(338.27, -883.75, 28.96),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [17] = {
        ['coords'] = vector3(343.81, -880.72, 29.47),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [18] = {
        ['coords'] = vector3(345.32, -877.78, 29.49),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [19] = {
        ['coords'] = vector3(345.91, -876.82, 29.49),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
    [20] = {
        ['coords'] = vector3(338.53, -882.4, 28.43),
        ['isOpened'] = false,
        ['isBusy'] = false,
    },
}
