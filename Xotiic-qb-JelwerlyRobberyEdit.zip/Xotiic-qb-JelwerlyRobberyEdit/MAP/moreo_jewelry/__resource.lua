-- client_script "@mapmanager/koobs.lua"

this_is_a_map "yes"

--data_file('DLC_ITYP_REQUEST')('stream/v_int_40.ytyp')
