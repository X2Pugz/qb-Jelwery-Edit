

-- -839087547 created by Xotiic ツ
Config.DoorList['jelweryrob--839087547'] = {
    distance = 2,
    items = { ['thermite'] = 1 },
    objName = -839087547,
    locked = true,
    objCoords = vec3(341.120911, -875.942932, 29.485561),
    doorRate = 1.0,
    objYaw = 179.99998474121,
    fixText = false,
    doorType = 'door',
}